package com.ryg.chapter_4;

import com.ryg.chapter_4.R;
import android.app.Activity;
import android.os.Bundle;

public class DemoActivity_1 extends Activity {
    private static final String TAG = "DemoActivity_1";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.demo_1);
        initView();
    }

    private void initView() {

    }

}
