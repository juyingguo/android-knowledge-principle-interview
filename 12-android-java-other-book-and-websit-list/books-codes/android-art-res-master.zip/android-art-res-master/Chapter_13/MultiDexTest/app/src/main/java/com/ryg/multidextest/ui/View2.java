package com.ryg.multidextest.ui;

/**
 * Created by renyugang on 15-5-27.
 */
public class View2 {
    public static String msg = "helloworld";
}
